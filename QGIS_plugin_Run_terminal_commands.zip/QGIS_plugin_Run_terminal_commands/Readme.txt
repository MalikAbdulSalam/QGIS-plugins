QGIS-plugins
This plugin will run terminal commands with QGIS plugin buttons

How to use?
Step-1:- 	Download pluging zip files 
Step-2:- 	For GNU/Linux machine unzip the file at '/home/USER/.local/share/QGIS/QGIS3/profiles/default/python/plugins'directory. 
		For Windows OS unzip the file at 'C:\Users\USER\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins'
		
