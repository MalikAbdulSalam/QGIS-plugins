cd /home/malik/.local/share/QGIS/QGIS3/profiles/default/python/plugins/malik_linker/terminal_commands/results
touch file_created.txt
