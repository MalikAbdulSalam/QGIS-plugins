from qgis.core import (
  QgsField,
  QgsFields,
  QgsVectorFileWriter)
root = os.path.expanduser('~')
outFile = root +  '/.local/share/QGIS/QGIS3/profiles/default/python/plugins/malik_linker//ESRI/Malik.shp'

layers = [l for l in QgsProject.instance().mapLayers().values() if l.type() == QgsVectorLayer.VectorLayer]

for l in layers:
    writer = QgsVectorFileWriter.writeAsVectorFormat(l, outFile, 'utf-8', driverName='ESRI Shapefile')








