QGIS-plugins
This plugin will export QGIS projec ESRI files in single click

How to Configure?
Step-1:- 	Download pluging zip files 
Step-2:- 	For GNU/Linux machine unzip the file and place "malik_linker" folder at '/home/USER/.local/share/QGIS/QGIS3/profiles/default/python/plugins/'directory. 
		For Windows OS :- unzip the file and place "malik_linker" folder at 'C\Users\USER\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\'
		
		
How to use?
Click on Plugin icon
dialog box will appear
click on "Export ESRI file" button to export ESRI
Result will be saved in "malik_linker/ESRI/" folder
